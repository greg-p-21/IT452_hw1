#implementation of aStart
from PriQue_1 import *
from world import *
def aStar(start):
    ##set up##
    closed = []
    opened = PriorityQueue()
    #goal = goal_locs
    parent = {}
    path = []
    origin = start
    #numNodeExpanded = 0

    #compare two world
    while ( start.__ne__() ):
        print("in aStar")
        closed.append(start)
        allSuccessors = start.getSuccessors()
        #print(allSuccessors)
        for w in allSuccessors :       ### w is a world
            if w not in closed :       ### expand

                ###  calculate F(w) of each successor
                ###  F(w) = G(w) + H(w)
                ###  G(w) cost to get to this world
                ###  H(w) cost to get to the goal => Heuristic
                Fcost = w.getCost() + w.distanceFromGoal()
                #print(w.getCost())
                #print(w.distanceFromGoal(goal))
                #update cost of each world
                w.updateCost(Fcost)

                ##point successor w back to its parent (start)
                parent[w] = start

                ##add eachSuccessor to opened
                opened.add(w.getCost(),w)

        start = opened.get() ####
        print(start.getCost())
        print(opened.len())


    #reconstruct the path
    #start.printWorld()
    path.append(start.getAction())
    done = 0
    while (done == 0):
        start.printWorld()
        path.append(parent[start].getAction())
        start = parent[start]
        if(start == origin):
            done = 1
    path.reverse()
    path.pop(0) #exclude the origin world

    return path

######################################################################################
